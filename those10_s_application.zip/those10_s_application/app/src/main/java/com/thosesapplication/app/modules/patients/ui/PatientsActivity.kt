package com.thosesapplication.app.modules.patients.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.thosesapplication.app.R
import com.thosesapplication.app.appcomponents.base.BaseActivity
import com.thosesapplication.app.databinding.ActivityPatientsBinding
import com.thosesapplication.app.modules.keyboard.ui.KeyboardActivity
import com.thosesapplication.app.modules.menu.ui.MenuActivity
import com.thosesapplication.app.modules.patients.`data`.viewmodel.PatientsVM
import kotlin.String
import kotlin.Unit

class PatientsActivity : BaseActivity<ActivityPatientsBinding>(R.layout.activity_patients) {
  private val viewModel: PatientsVM by viewModels<PatientsVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.patientsVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.linearRowsearch.setOnClickListener {
      val destIntent = KeyboardActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMenu.setOnClickListener {
      val destIntent = MenuActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "PATIENTS_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, PatientsActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
