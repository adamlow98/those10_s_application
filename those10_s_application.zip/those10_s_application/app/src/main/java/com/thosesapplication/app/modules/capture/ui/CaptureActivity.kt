package com.thosesapplication.app.modules.capture.ui

import androidx.activity.viewModels
import com.thosesapplication.app.R
import com.thosesapplication.app.appcomponents.base.BaseActivity
import com.thosesapplication.app.databinding.ActivityCaptureBinding
import com.thosesapplication.app.modules.capture.`data`.viewmodel.CaptureVM
import com.thosesapplication.app.modules.menu.ui.MenuActivity
import kotlin.String
import kotlin.Unit

class CaptureActivity : BaseActivity<ActivityCaptureBinding>(R.layout.activity_capture) {
  private val viewModel: CaptureVM by viewModels<CaptureVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.captureVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
    binding.linearMenu.setOnClickListener {
      val destIntent = MenuActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "CAPTURE_ACTIVITY"

  }
}
