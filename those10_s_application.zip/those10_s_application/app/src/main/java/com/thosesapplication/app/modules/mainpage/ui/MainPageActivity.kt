package com.thosesapplication.app.modules.mainpage.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.widget.SearchView
import com.thosesapplication.app.R
import com.thosesapplication.app.appcomponents.base.BaseActivity
import com.thosesapplication.app.databinding.ActivityMainPageBinding
import com.thosesapplication.app.modules.mainpage.`data`.model.MainPageRowModel
import com.thosesapplication.app.modules.mainpage.`data`.viewmodel.MainPageVM
import com.thosesapplication.app.modules.menu.ui.MenuActivity
import com.thosesapplication.app.modules.patients.ui.PatientsActivity
import kotlin.Boolean
import kotlin.Int
import kotlin.String
import kotlin.Unit

class MainPageActivity : BaseActivity<ActivityMainPageBinding>(R.layout.activity_main_page) {
  private val viewModel: MainPageVM by viewModels<MainPageVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val mainPageAdapter = MainPageAdapter(viewModel.mainPageList.value?:mutableListOf())
    binding.recyclerMainPage.adapter = mainPageAdapter
    mainPageAdapter.setOnItemClickListener(
    object : MainPageAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : MainPageRowModel) {
        onClickRecyclerMainPage(view, position, item)
      }
    }
    )
    viewModel.mainPageList.observe(this) {
      mainPageAdapter.updateData(it)
    }
    binding.mainPageVM = viewModel
    setUpSearchViewGroupSeventeenListener()
  }

  override fun setUpClicks(): Unit {
    binding.linearMenu.setOnClickListener {
      val destIntent = MenuActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtLanguageEight.setOnClickListener {
      val destIntent = PatientsActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtLanguageFour.setOnClickListener {
      val destIntent = PatientsActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtLanguageOne.setOnClickListener {
      val destIntent = PatientsActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtLanguageNine.setOnClickListener {
      val destIntent = PatientsActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtLanguageSeven.setOnClickListener {
      val destIntent = PatientsActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  fun onClickRecyclerMainPage(
    view: View,
    position: Int,
    item: MainPageRowModel
  ): Unit {
    when(view.id) {
    }
  }

  private fun setUpSearchViewGroupSeventeenListener(): Unit {
    binding.searchViewGroupSeventeen.setOnQueryTextListener(object :
    SearchView.OnQueryTextListener {
      override fun onQueryTextSubmit(p0 : String) : Boolean {
        // Performs search when user hit
        // the search button on the keyboard
        return false
      }
      override fun onQueryTextChange(p0 : String) : Boolean {
        // Start filtering the list as user
        // start entering the characters
        return false
      }
      })
    }

    companion object {
      const val TAG: String = "MAIN_PAGE_ACTIVITY"


      fun getIntent(context: Context, bundle: Bundle?): Intent {
        val destIntent = Intent(context, MainPageActivity::class.java)
        destIntent.putExtra("bundle", bundle)
        return destIntent
      }
    }
  }
