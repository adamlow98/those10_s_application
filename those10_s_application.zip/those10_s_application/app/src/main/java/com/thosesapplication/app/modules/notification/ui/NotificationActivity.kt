package com.thosesapplication.app.modules.notification.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.thosesapplication.app.R
import com.thosesapplication.app.appcomponents.base.BaseActivity
import com.thosesapplication.app.databinding.ActivityNotificationBinding
import com.thosesapplication.app.modules.chatbox.ui.ChatBoxActivity
import com.thosesapplication.app.modules.menu.ui.MenuActivity
import com.thosesapplication.app.modules.notification.`data`.viewmodel.NotificationVM
import kotlin.String
import kotlin.Unit

class NotificationActivity :
    BaseActivity<ActivityNotificationBinding>(R.layout.activity_notification) {
  private val viewModel: NotificationVM by viewModels<NotificationVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.notificationVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.txtTwoTwo.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtDrMarthaOne.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageProfilePictureThree.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtDrStevenOne.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtTwoOne.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtPriceFive.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtDrKateOne.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtPriceThree.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumntwoOne.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtPriceFour.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearMenu.setOnClickListener {
      val destIntent = MenuActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumntwo.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtPrice.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtTwoThree.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageProfilePictureFour.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageProfilePictureFive.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtDrKate.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtDrSteven.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtPriceOne.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtPriceTwo.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageProfilePictureOne.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtDrMartha.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageProfilePicture.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtTwo.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageProfilePictureTwo.setOnClickListener {
      val destIntent = ChatBoxActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "NOTIFICATION_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, NotificationActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
